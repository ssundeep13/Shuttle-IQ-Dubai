"use client"

import { Trophy } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Player {
  id: number
  name: string
  initials: string
  winPercentage: number
  gamesPlayed: number
}

const topPlayers: Player[] = [
  { id: 1, name: "Sarah Chen", initials: "SC", winPercentage: 78, gamesPlayed: 45 },
  { id: 2, name: "Mike Johnson", initials: "MJ", winPercentage: 72, gamesPlayed: 38 },
  { id: 3, name: "Anna Lee", initials: "AL", winPercentage: 68, gamesPlayed: 52 },
  { id: 4, name: "David Kim", initials: "DK", winPercentage: 65, gamesPlayed: 41 },
  { id: 5, name: "Emma Wilson", initials: "EW", winPercentage: 62, gamesPlayed: 33 },
]

function getRankStyle(rank: number) {
  switch (rank) {
    case 1:
      return "bg-amber-500 text-white"
    case 2:
      return "bg-gray-400 text-white"
    case 3:
      return "bg-amber-700 text-white"
    default:
      return "bg-secondary text-muted-foreground"
  }
}

export function Leaderboard() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-amber-500" />
          <CardTitle className="text-lg font-semibold text-card-foreground">
            Top Players
          </CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {topPlayers.map((player, index) => (
          <div
            key={player.id}
            className="group flex items-center gap-3 rounded-lg p-2 transition-colors hover:bg-secondary/50"
          >
            <div
              className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${getRankStyle(index + 1)}`}
            >
              {index + 1}
            </div>
            <Avatar className="h-9 w-9">
              <AvatarImage src={`/placeholder-avatar-${player.id}.jpg`} alt={player.name} />
              <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
                {player.initials}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-card-foreground truncate">
                {player.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {player.gamesPlayed} games
              </p>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-accent">
                {player.winPercentage}%
              </p>
              <p className="text-xs text-muted-foreground">win rate</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

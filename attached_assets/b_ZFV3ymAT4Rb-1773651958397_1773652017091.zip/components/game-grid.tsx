"use client"

import { Calendar, MapPin } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface Game {
  id: number
  date: string
  dayOfWeek: string
  venue: string
  location: string
  slotsAvailable: number
  totalSlots: number
}

const games: Game[] = [
  {
    id: 1,
    date: "Mar 18",
    dayOfWeek: "Tuesday",
    venue: "Barsha Sports Hall",
    location: "Court 1",
    slotsAvailable: 8,
    totalSlots: 12,
  },
  {
    id: 2,
    date: "Mar 20",
    dayOfWeek: "Thursday",
    venue: "Sports City",
    location: "Court 2",
    slotsAvailable: 5,
    totalSlots: 12,
  },
  {
    id: 3,
    date: "Mar 22",
    dayOfWeek: "Saturday",
    venue: "Dubai Sports World",
    location: "Indoor Arena",
    slotsAvailable: 10,
    totalSlots: 12,
  },
  {
    id: 4,
    date: "Mar 25",
    dayOfWeek: "Tuesday",
    venue: "Al Nasr Club",
    location: "Court 3",
    slotsAvailable: 3,
    totalSlots: 12,
  },
]

function SlotProgress({
  available,
  total,
}: {
  available: number
  total: number
}) {
  const percentage = (available / total) * 100
  const isLow = available <= 4

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">Slots Available</span>
        <span
          className={`font-semibold ${isLow ? "text-orange-500" : "text-accent"}`}
        >
          {available}/{total}
        </span>
      </div>
      <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
        <div
          className={`h-full rounded-full transition-all duration-300 ${isLow ? "bg-orange-500" : "bg-accent"}`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}

export function GameGrid() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-card-foreground">
          Upcoming Games
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {games.map((game) => (
          <div
            key={game.id}
            className="group rounded-xl border border-border bg-card p-4 transition-all hover:border-accent/30 hover:shadow-sm"
          >
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-4">
                <div className="flex h-14 w-14 flex-col items-center justify-center rounded-lg bg-secondary">
                  <Calendar className="h-5 w-5 text-primary" />
                  <span className="mt-0.5 text-xs font-semibold text-primary">
                    {game.date}
                  </span>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">
                    {game.dayOfWeek}
                  </p>
                  <h4 className="font-semibold text-card-foreground">
                    {game.venue}
                  </h4>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" />
                    <span className="text-sm">{game.location}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-3 sm:w-48">
                <SlotProgress
                  available={game.slotsAvailable}
                  total={game.totalSlots}
                />
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  Reserve Spot
                </Button>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

"use client"

import { MapPin, Clock, Users } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function NextSession() {
  return (
    <Card className="overflow-hidden border-border bg-card">
      <div className="bg-primary px-6 py-3">
        <p className="text-sm font-medium text-primary-foreground/80">
          Next Session
        </p>
      </div>
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <h3 className="text-2xl font-bold text-card-foreground">
                Sports City
              </h3>
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span className="text-sm">Court 3, Indoor Arena</span>
              </div>
            </div>
            <div className="flex items-center gap-1 rounded-full bg-accent/10 px-3 py-1">
              <Users className="h-4 w-4 text-accent" />
              <span className="text-sm font-medium text-accent">8/12</span>
            </div>
          </div>

          <div className="flex items-center gap-3 rounded-lg bg-secondary p-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
              <Clock className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Today</p>
              <p className="text-lg font-semibold text-card-foreground">
                7:00 PM - 9:00 PM
              </p>
            </div>
          </div>

          <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90 transition-transform hover:scale-[1.02] active:scale-[0.98]">
            Join Game
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

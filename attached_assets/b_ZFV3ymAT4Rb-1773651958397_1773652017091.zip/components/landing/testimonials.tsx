"use client"

import { motion } from "framer-motion"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Ahmed K.",
    role: "Weekly Player",
    initials: "AK",
    content: "Finally, no more WhatsApp groups to organize games. ShuttleIQ just works. I have played 3x more since joining.",
    rating: 5,
  },
  {
    name: "Sarah M.",
    role: "Tournament Player",
    initials: "SM",
    content: "The leaderboard feature is addictive. Love seeing my ranking improve week over week!",
    rating: 5,
  },
  {
    name: "Raj P.",
    role: "Casual Player",
    initials: "RP",
    content: "As a beginner, I was worried about skill matching. The app pairs me with players at my level perfectly.",
    rating: 5,
  },
]

export function Testimonials() {
  return (
    <section className="bg-primary py-24 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold uppercase tracking-wider text-accent"
          >
            Testimonials
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-3 text-balance text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl"
          >
            Loved by players across Dubai
          </motion.h2>
        </div>

        {/* Testimonials Grid */}
        <div className="mx-auto mt-16 grid max-w-5xl gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="rounded-2xl bg-card p-6 shadow-xl"
            >
              {/* Stars */}
              <div className="flex gap-1">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>
              
              {/* Content */}
              <p className="mt-4 text-card-foreground">
                &ldquo;{testimonial.content}&rdquo;
              </p>
              
              {/* Author */}
              <div className="mt-6 flex items-center gap-3">
                <Avatar className="h-10 w-10 border-2 border-accent/20">
                  <AvatarFallback className="bg-accent/10 text-sm font-medium text-accent">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium text-card-foreground">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

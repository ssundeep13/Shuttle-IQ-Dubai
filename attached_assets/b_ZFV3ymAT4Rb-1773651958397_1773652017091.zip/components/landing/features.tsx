"use client"

import { motion } from "framer-motion"
import { Users, Trophy, Calendar, Zap, MapPin, BarChart3 } from "lucide-react"

const features = [
  {
    icon: Calendar,
    title: "Smart Queue System",
    description: "Join games instantly. Our algorithm matches you with players at your skill level.",
  },
  {
    icon: Trophy,
    title: "Live Leaderboards",
    description: "Track your ranking, climb the charts, and compete with the best in your community.",
  },
  {
    icon: BarChart3,
    title: "Performance Stats",
    description: "Detailed analytics on your games, win rates, and improvement over time.",
  },
  {
    icon: Users,
    title: "Find Your Doubles",
    description: "Match with compatible partners based on play style and availability.",
  },
  {
    icon: MapPin,
    title: "Multi-Venue Support",
    description: "Play at any of our partner venues across Dubai. One app, endless courts.",
  },
  {
    icon: Zap,
    title: "Instant Notifications",
    description: "Get alerted when it's your turn or when a spot opens up at your favorite time.",
  },
]

export function Features() {
  return (
    <section className="bg-card py-24 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold uppercase tracking-wider text-accent"
          >
            Features
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-3 text-balance text-3xl font-bold tracking-tight text-card-foreground sm:text-4xl"
          >
            Everything you need to play smarter
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-4 text-lg text-muted-foreground"
          >
            From queuing to tracking, we have got every aspect of your badminton game covered.
          </motion.p>
        </div>

        {/* Features Grid */}
        <div className="mx-auto mt-16 grid max-w-5xl gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative rounded-2xl border border-border bg-background p-6 transition-all hover:border-accent/30 hover:shadow-lg hover:shadow-accent/5"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent transition-colors group-hover:bg-accent group-hover:text-accent-foreground">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-muted-foreground">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { motion } from "framer-motion"

export function CTA() {
  return (
    <section className="bg-background py-24 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative mx-auto max-w-4xl overflow-hidden rounded-3xl bg-gradient-to-br from-accent to-accent/80 p-8 shadow-2xl shadow-accent/20 sm:p-12 lg:p-16"
        >
          {/* Background decoration */}
          <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
          
          <div className="relative text-center">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-accent-foreground sm:text-4xl lg:text-5xl">
              Ready to level up your game?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-lg text-accent-foreground/80">
              Join 500+ players who have already transformed how they play badminton in Dubai.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button
                size="lg"
                className="group h-12 min-w-[200px] bg-white text-accent shadow-lg transition-all hover:bg-white/90 hover:shadow-xl"
              >
                Start Playing Today
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <span className="text-sm text-accent-foreground/70">
                Free forever for players
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

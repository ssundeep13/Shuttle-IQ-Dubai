export function Footer() {
  return (
    <footer className="border-t border-border bg-card py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                className="h-4 w-4 text-accent-foreground"
                stroke="currentColor"
                strokeWidth="2"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 2v20M2 12h20" />
              </svg>
            </div>
            <span className="text-lg font-bold text-card-foreground">ShuttleIQ</span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <a href="#" className="transition-colors hover:text-foreground">Privacy</a>
            <a href="#" className="transition-colors hover:text-foreground">Terms</a>
            <a href="#" className="transition-colors hover:text-foreground">Contact</a>
            <a href="#" className="transition-colors hover:text-foreground">Support</a>
          </div>

          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            2024 ShuttleIQ. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}

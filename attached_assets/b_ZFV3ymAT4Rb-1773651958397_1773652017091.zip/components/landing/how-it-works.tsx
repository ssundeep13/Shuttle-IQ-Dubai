"use client"

import { motion } from "framer-motion"

const steps = [
  {
    number: "01",
    title: "Sign up in seconds",
    description: "Create your profile with just your email. Add your skill level and preferred venues.",
  },
  {
    number: "02",
    title: "Join a session",
    description: "Browse upcoming games at your favorite venues and join the queue with one tap.",
  },
  {
    number: "03",
    title: "Play and improve",
    description: "Show up, play your games, and watch your stats and ranking climb automatically.",
  },
]

export function HowItWorks() {
  return (
    <section className="bg-background py-24 sm:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold uppercase tracking-wider text-accent"
          >
            How It Works
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-3 text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
          >
            Get on the court in three steps
          </motion.h2>
        </div>

        {/* Steps */}
        <div className="mx-auto mt-16 max-w-4xl">
          <div className="grid gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="relative text-center"
              >
                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="absolute left-1/2 top-8 hidden h-0.5 w-full bg-gradient-to-r from-accent/50 to-accent/10 md:block" />
                )}
                
                {/* Step Number */}
                <div className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent text-xl font-bold text-accent-foreground shadow-lg shadow-accent/25">
                  {step.number}
                </div>
                
                <h3 className="mt-6 text-lg font-semibold text-foreground">
                  {step.title}
                </h3>
                <p className="mt-2 text-muted-foreground">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

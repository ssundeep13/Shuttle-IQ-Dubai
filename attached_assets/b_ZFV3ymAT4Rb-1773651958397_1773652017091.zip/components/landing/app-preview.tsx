"use client"

import { motion } from "framer-motion"
import { MapPin, Clock, Users, Trophy, TrendingUp } from "lucide-react"

export function AppPreview() {
  return (
    <section className="bg-muted py-24 sm:py-32" id="features">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mx-auto max-w-2xl text-center">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-semibold uppercase tracking-wider text-accent"
          >
            App Preview
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="mt-3 text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
          >
            See what awaits you
          </motion.h2>
        </div>

        {/* Preview Cards */}
        <div className="mx-auto mt-16 max-w-5xl">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Upcoming Session Card */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl bg-card p-6 shadow-xl lg:col-span-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-muted-foreground">Next Session</span>
                <span className="rounded-full bg-accent/10 px-3 py-1 text-xs font-medium text-accent">
                  Live Now
                </span>
              </div>
              <h3 className="mt-4 text-xl font-bold text-card-foreground">Thursday Night Doubles</h3>
              <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-accent" />
                  Dubai Sports City
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-accent" />
                  7:00 PM - 10:00 PM
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="h-4 w-4 text-accent" />
                  12/16 Players
                </div>
              </div>
              <div className="mt-4">
                <div className="h-2 overflow-hidden rounded-full bg-muted">
                  <div className="h-full w-3/4 rounded-full bg-accent" />
                </div>
                <p className="mt-2 text-xs text-muted-foreground">4 spots remaining</p>
              </div>
            </motion.div>

            {/* Leaderboard Preview */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl bg-card p-6 shadow-xl"
            >
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-accent" />
                <span className="font-semibold text-card-foreground">Leaderboard</span>
              </div>
              <div className="mt-4 space-y-3">
                {[
                  { rank: 1, name: "Alex T.", wins: 24, change: "+2" },
                  { rank: 2, name: "Maria S.", wins: 22, change: "+1" },
                  { rank: 3, name: "John D.", wins: 20, change: "-1" },
                ].map((player) => (
                  <div key={player.rank} className="flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2">
                    <div className="flex items-center gap-3">
                      <span className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${
                        player.rank === 1 ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"
                      }`}>
                        {player.rank}
                      </span>
                      <span className="text-sm font-medium text-card-foreground">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">{player.wins}W</span>
                      <span className="text-xs text-accent">{player.change}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Stats Preview */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="rounded-2xl bg-primary p-6 shadow-xl"
            >
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary-foreground" />
                <span className="font-semibold text-primary-foreground">Your Stats</span>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-2xl font-bold text-primary-foreground">72%</p>
                  <p className="text-xs text-primary-foreground/70">Win Rate</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary-foreground">18</p>
                  <p className="text-xs text-primary-foreground/70">Games Played</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-accent">5</p>
                  <p className="text-xs text-primary-foreground/70">Win Streak</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary-foreground">#12</p>
                  <p className="text-xs text-primary-foreground/70">Ranking</p>
                </div>
              </div>
            </motion.div>

            {/* Venue Card */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="rounded-2xl bg-card p-6 shadow-xl lg:col-span-2"
            >
              <span className="text-sm font-medium text-muted-foreground">Partner Venues</span>
              <div className="mt-4 flex flex-wrap gap-3">
                {["Dubai Sports City", "Al Nasr Club", "Meydan Badminton", "JLT Sports Hub", "DIFC Courts"].map((venue) => (
                  <span
                    key={venue}
                    className="rounded-full border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-accent hover:bg-accent/5"
                  >
                    {venue}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

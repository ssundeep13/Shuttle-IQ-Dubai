"use client"

import { Flame, Target, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface StatItem {
  icon: React.ReactNode
  label: string
  value: string | number
  subtext?: string
}

export function PlayerStats() {
  const stats: StatItem[] = [
    {
      icon: <Target className="h-5 w-5 text-primary" />,
      label: "Games Played",
      value: 24,
      subtext: "This month",
    },
    {
      icon: <Flame className="h-5 w-5 text-orange-500" />,
      label: "Win Streak",
      value: 5,
      subtext: "Current",
    },
    {
      icon: <TrendingUp className="h-5 w-5 text-accent" />,
      label: "Win Rate",
      value: "67%",
      subtext: "+5% from last month",
    },
  ]

  return (
    <Card className="border-border bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold text-card-foreground">
          Quick Stats
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="flex items-center gap-4 rounded-lg bg-secondary/50 p-3"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-card">
              {stat.icon}
            </div>
            <div className="flex-1">
              <p className="text-sm text-muted-foreground">{stat.label}</p>
              <p className="text-xl font-bold text-card-foreground">
                {stat.value}
              </p>
            </div>
            {stat.subtext && (
              <p className="text-xs text-muted-foreground text-right max-w-[80px]">
                {stat.subtext}
              </p>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
